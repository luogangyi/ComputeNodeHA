Automatic check status of nova compute nodes,
if service is enabled but was down on a node,
all the instances on this node would be evacuated to
other available host.